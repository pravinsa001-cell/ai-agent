# Independent Signal Lab (beginner starter)

A mobile-friendly educational chart-analysis dashboard using RSI(14), ATR(14), EMA(9), and EMA(21).

## Safety / scope
- Does not connect to Binomo.
- Does not place trades or access broker accounts.
- Uses synthetic demo candles or a CSV you provide.
- CALL/PUT labels are rule-based example setups, not reliable predictions or financial advice.

## Run locally
1. Install Python 3.11 or newer.
2. Open a terminal in this folder.
3. Install packages:
   `python -m pip install -r requirements.txt`
4. Start the app:
   `streamlit run app.py`
5. Open the local URL shown in the terminal.

## CSV format
Required columns (case-insensitive): `open, high, low, close`
Optional time column: `timestamp` (or `date`, `time`, `datetime`).

Example:
```csv
timestamp,open,high,low,close
2026-01-01 10:00:00,1.1000,1.1010,1.0995,1.1005
```
Upload at least 30 valid candles. Use historical data you are permitted to use. Check its time zone, candle interval, and source before analysis.

## Deploy for iPhone access
One simple route is Streamlit Community Cloud:
1. Create a GitHub repository and upload `app.py` and `requirements.txt`.
2. Sign in at https://share.streamlit.io/
3. Choose **Create app**, select your repository and `app.py`, then deploy.
4. Open the resulting `*.streamlit.app` link in Safari on your iPhone.
5. Review repository/app visibility settings carefully. Do not upload API keys, passwords, private account information, or confidential data.

See the official guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy

## Before real-world use
- Add a historical backtest with out-of-sample periods.
- Include realistic payout/transaction assumptions if evaluating short-term options.
- Avoid look-ahead bias; use only completed candles for signals.
- Track sample size, drawdown, and results across different market conditions.
- Never assume a setup or confidence score guarantees a win.
